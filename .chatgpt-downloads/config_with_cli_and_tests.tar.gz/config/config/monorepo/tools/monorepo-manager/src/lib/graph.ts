import fs from 'fs/promises';
import path from 'path';
import { readModulesMap } from './modules';

export async function dependencyGraph(): Promise<Record<string,string[]>> {
  const modules = await readModulesMap();
  const out: Record<string,string[]> = {};
  const names = Object.keys(modules);
  for (const [name, p] of Object.entries(modules)) {
    out[name] = [];
    try {
      const files = await collectFiles(p);
      const text = files.map(f=>f.content).join('\n');
      for (const other of names) {
        if (other === name) continue;
        if (text.includes(other) || text.includes(modules[other])) out[name].push(other);
      }
    } catch (e) {
      // ignore missing modules
    }
  }
  return out;
}

export async function graphToDot(graph: Record<string,string[]>, outPath: string) {
  const lines = ['digraph G {', '  rankdir=LR;'];
  for (const [from, tos] of Object.entries(graph)) {
    const fromId = sanitize(from);
    if (tos.length === 0) {
      lines.push(`  "${fromId}";`);
    } else {
      for (const to of tos) {
        lines.push(`  "${sanitize(from)}" -> "${sanitize(to)}";`);
      }
    }
  }
  lines.push('}');
  await fs.writeFile(outPath, lines.join('\n'), 'utf8');
}

function sanitize(s: string) { return s.replace(/[^a-zA-Z0-9_\-]/g, '_'); }

async function collectFiles(root: string) {
  const fsr = await import('fs');
  const res: {path:string,content:string}[] = [];
  async function walk(dir: string) {
    let entries;
    try { entries = await fs.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) await walk(p);
      else {
        try { const c = await fs.readFile(p, 'utf8'); res.push({path:p,content:c}); } catch {}
      }
    }
  }
  await walk(root);
  return res;
}
