#!/usr/bin/env sh
set -eu
echo "publish-java placeholder"
