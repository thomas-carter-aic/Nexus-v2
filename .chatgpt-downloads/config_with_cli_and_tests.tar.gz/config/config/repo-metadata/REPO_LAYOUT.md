# Monorepo layout

See repo conventions.
