#!/usr/bin/env bash
set -euo pipefail
echo "Running release orchestrator based on build-order.yaml..."
