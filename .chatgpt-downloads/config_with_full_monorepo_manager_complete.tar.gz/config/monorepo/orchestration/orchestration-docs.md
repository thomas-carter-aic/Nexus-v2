# Orchestration Docs

This directory defines **how the monorepo is orchestrated** for builds, tests, and releases.

## Files
- `build-order.yaml`  : Canonical ordering of stages and modules across all languages.
- `release-orchestrator.sh` : Shell script to execute builds stage-by-stage.
- `orchestration-docs.md` : This file — describes purpose and usage.

## Workflow
1. Add/update modules in `build-order.yaml`.
2. CI/CD pipelines call `release-orchestrator.sh` to run builds in order.
3. CLI (`monorepo-manager graph`) visualizes the graph defined in `build-order.yaml`.

## Stages
- **base-languages**: language runtimes, base Dockerfiles.
- **shared-libraries**: common libs for services.
- **core-services**: polyglot microservices.
- **ai-platform**: ML/AI services and pipelines.
- **integrations**: external integrations.
- **release-packaging**: publishing scripts and packaging outputs.
