#!/usr/bin/env bash
echo "Detecting changed modules..."
git diff --name-only HEAD~1 HEAD | grep -E 'services/|libs/' || true
