import assert from 'assert/strict';
import { listModules, readModulesMap } from '../lib/modules';
import { dependencyGraph, graphToDot } from '../lib/graph';
import fs from 'fs/promises';
import path from 'path';

async function main() {
  const mods = await listModules();
  assert(Array.isArray(mods), 'listModules should return an array');
  const map = await readModulesMap();
  assert(map && typeof map === 'object', 'readModulesMap should return object');

  const graph = await dependencyGraph();
  assert(typeof graph === 'object', 'graph should be an object');
  const out = path.resolve(process.cwd(), 'tmp_graph.dot');
  await graphToDot(graph, out);
  const exists = await fs.stat(out);
  console.log('Graph DOT written to', out);
  console.log('All CLI tests passed ✅');
}

main().catch(e=>{ console.error(e); process.exit(1); });
