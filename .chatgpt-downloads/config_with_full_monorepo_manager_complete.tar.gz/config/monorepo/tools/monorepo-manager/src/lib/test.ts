import { execaCommand } from 'execa';
import pMap from 'p-map';
import path from 'path';
import fs from 'fs/promises';

async function runTestForModule(m: string): Promise<void> {
  if (await fileExists(path.join(m, 'package.json'))) {
    await execaCommand('npm test', { cwd: m, stdio: 'inherit' });
  } else if (await fileExists(path.join(m, 'pom.xml'))) {
    await execaCommand('mvn -B test', { cwd: m, stdio: 'inherit' });
  } else if (await fileExists(path.join(m, 'go.mod'))) {
    await execaCommand('go test ./...', { cwd: m, stdio: 'inherit' });
  } else {
    console.warn(`No known test runner for ${m}; skipping`);
  }
}

async function fileExists(p: string) {
  try { await fs.access(p); return true; } catch { return false; }
}

export async function runTests(modules: string[], concurrency = 4) {
  await pMap(modules, runTestForModule, { concurrency });
}
