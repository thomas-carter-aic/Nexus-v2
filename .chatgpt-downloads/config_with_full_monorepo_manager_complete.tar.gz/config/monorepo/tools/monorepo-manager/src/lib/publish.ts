import path from 'path';
import fs from 'fs/promises';
import { execaCommand } from 'execa';
import { readModulesMap } from './modules';

export async function publishModule(modulePathOrName: string): Promise<void> {
  const modules = await readModulesMap();
  const byName = modules[modulePathOrName];
  const modulePath = byName || modulePathOrName;
  const scriptDir = path.resolve(process.cwd(), 'config/monorepo/publishing');

  try {

    if ((await fs.stat(scriptDir)).isDirectory()) {

      const files = await fs.readdir(scriptDir);
      if (files.includes('publish-python.sh') && await fileExists(path.join(modulePath, 'pyproject.toml'))) {
        await execaCommand(`${path.join(scriptDir,'publish-python.sh')} ${modulePath}`, { stdio: 'inherit' });
        return;
      }
     if (files.includes('publish-rust.sh') && await fileExists(path.join(modulePath, 'Cargo.toml'))) {
        await execaCommand(`${path.join(scriptDir,'publish-rust.sh')} ${modulePath}`, { stdio: 'inherit' });
        return;
      }

      if (files.includes('publish-node.sh') && await fileExists(path.join(modulePath, 'package.json'))) {
        await execaCommand(`${path.join(scriptDir,'publish-node.sh')} ${modulePath}`, { stdio: 'inherit' });
        return;
      }
      if (files.includes('publish-java.sh') && await fileExists(path.join(modulePath, 'pom.xml'))) {
        await execaCommand(`${path.join(scriptDir,'publish-java.sh')} ${modulePath}`, { stdio: 'inherit' });
        return;
      }
      if (files.includes('publish-go.sh') && await fileExists(path.join(modulePath, 'go.mod'))) {
        await execaCommand(`${path.join(scriptDir,'publish-go.sh')} ${modulePath}`, { stdio: 'inherit' });
        return;
      }
    }
  } catch (e) {
  }

  if (await fileExists(path.join(modulePath, 'package.json'))) {
    await execaCommand('npm publish --access public', { cwd: modulePath, stdio: 'inherit' });
  } else if (await fileExists(path.join(modulePath, 'pom.xml'))) {
    await execaCommand('mvn -B -DskipTests deploy', { cwd: modulePath, stdio: 'inherit' });
  } else {
    throw new Error(`No publish mechanism for ${modulePath}`);
  }
}

async function fileExists(p:string) { try { await fs.stat(p); return true } catch { return false } }

export async function orchestrateRelease(opts: { skipTests?: boolean } = {}) {
  const buildOrderPath = path.resolve(process.cwd(), 'config/repo-metadata/build-order.yaml');
  try {
    const raw = await fs.readFile(buildOrderPath, 'utf8');
    const modules = raw.split('\n').map(l=>l.trim()).filter(Boolean).map(l=>l.replace(/^-\s*/,''));
    for (const m of modules) {
      console.log('Releasing', m);
      const map = await readModulesMap();
      const p = map[m];
      if (!p) { console.warn('No path for', m); continue; }
      if (!opts.skipTests) {
        try { await execaCommand('npm test', { cwd: p, stdio: 'inherit' }); } catch(e) { console.warn('Tests failed for', p); throw e; }
      }
      await publishModule(p);
    }
  } catch (e) {
    console.error('Failed to orchestrate release:', e);
    throw e;
  }
}
