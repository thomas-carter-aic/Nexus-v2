import pMap from 'p-map';
import { execaCommand } from 'execa';

export async function runParallel(cmds: string[], concurrency = 4) {
  await pMap(cmds, async (c) => {
    console.log('> ', c);
    await execaCommand(c, { stdio: 'inherit', shell: true });
  }, { concurrency });
}
