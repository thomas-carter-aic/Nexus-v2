import { Command } from "commander";
import fs from "fs";
import path from "path";
import { generateGraph } from "../lib/dependency-graph";

export const graphCommand = new Command("graph")
  .description("Generate a dependency graph for all modules/services")
  .option("--format <format>", "Output format: dot, svg, png", "dot")
  .option("--out <file>", "Output file path", "dependency-graph.dot")
  .action(async (opts) => {
    const modules = generateGraph(); // returns adjacency list
    const dot = convertToDot(modules); // converts to DOT syntax

    fs.writeFileSync(opts.out, dot);
    console.log(`✅ Dependency graph saved to ${opts.out}`);

    // Optional: convert to PNG/SVG using dot if requested
    if (opts.format !== "dot") {
      const outFile = opts.out.replace(/\.dot$/, `.${opts.format}`);
      require("child_process").execSync(`dot -T${opts.format} ${opts.out} -o ${outFile}`);
      console.log(`✅ Converted to ${opts.format}: ${outFile}`);
    }
  });

// Utility function to convert adjacency list to DOT
function convertToDot(modules: Record<string,string[]>): string {
  let dot = "digraph G {\n";
  for (const [mod, deps] of Object.entries(modules)) {
    if (deps.length === 0) {
      dot += `  "${mod}";\n`;
    } else {
      deps.forEach(dep => {
        dot += `  "${mod}" -> "${dep}";\n`;
      });
    }
  }
  dot += "}\n";
  return dot;
}
