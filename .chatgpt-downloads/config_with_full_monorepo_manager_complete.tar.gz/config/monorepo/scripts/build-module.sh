#!/usr/bin/env bash
set -euo pipefail
MODULE="$1"
echo "🔨 Building $MODULE..."
# Language detection and build
if [ -f "$MODULE/pom.xml" ]; then
  (cd "$MODULE" && mvn clean install -B)
elif [ -f "$MODULE/package.json" ]; then
  (cd "$MODULE" && npm install && npm run build)
elif [ -f "$MODULE/pyproject.toml" ]; then
  (cd "$MODULE" && python3 -m pip install --upgrade build wheel setuptools && python3 -m build)
elif [ -f "$MODULE/Cargo.toml" ]; then
  (cd "$MODULE" && cargo build --release)
elif [ -f "$MODULE/go.mod" ]; then
  (cd "$MODULE" && go build ./...)
else
  echo "⚠️ Unknown language, skipping."
fi
