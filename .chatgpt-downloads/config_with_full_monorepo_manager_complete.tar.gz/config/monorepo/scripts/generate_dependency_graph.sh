#!/usr/bin/env bash
set -euo pipefail
FORMAT="${1:-svg}"
OUT_DIR="./graphs"
OUT_FILE="$OUT_DIR/dependency-graph.dot"
mkdir -p "$OUT_DIR"
npx ts-node ./monorepo-manager/src/cli.ts graph --format dot --out "$OUT_FILE"
if [ "$FORMAT" != "dot" ]; then
  dot -T"$FORMAT" "$OUT_FILE" -o "$OUT_DIR/dependency-graph.$FORMAT"
fi
