#!/usr/bin/env bash
set -euo pipefail
BUILD_ORDER="config/monorepo/orchestration/build-order.yaml"
if ! command -v yq &>/dev/null; then
  echo "❌ yq is required"
  exit 1
fi
echo "🚀 Starting release orchestrator"
STAGES=$(yq '.stages[].name' "$BUILD_ORDER")
for stage in $STAGES; do
  echo ""
  echo "=== Stage: $stage ==="
  MODULES=$(yq ".stages[] | select(.name==\"$stage\") | .modules[]" "$BUILD_ORDER")
  for mod in $MODULES; do
    (
      echo "🔨 Building $mod"
      ./monorepo/scripts/build-module.sh "$mod"
    ) &
  done
  wait
done
echo "✅ Release orchestration complete."
