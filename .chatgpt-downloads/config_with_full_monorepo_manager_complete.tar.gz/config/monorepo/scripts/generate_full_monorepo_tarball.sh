#!/usr/bin/env bash
set -euo pipefail

OUT_DIR="./config"
mkdir -p "$OUT_DIR"

echo "📦 Creating fully populated config/ scaffold..."

# -------------------------------
# 1️⃣ Monorepo scripts
# -------------------------------
mkdir -p "$OUT_DIR/monorepo/scripts"

cat > "$OUT_DIR/monorepo/scripts/build-module.sh" << 'EOF'
#!/usr/bin/env bash
set -euo pipefail
MODULE="$1"
echo "🔨 Building $MODULE..."
# Language detection and build
if [ -f "$MODULE/pom.xml" ]; then
  (cd "$MODULE" && mvn clean install -B)
elif [ -f "$MODULE/package.json" ]; then
  (cd "$MODULE" && npm install && npm run build)
elif [ -f "$MODULE/pyproject.toml" ]; then
  (cd "$MODULE" && python3 -m pip install --upgrade build wheel setuptools && python3 -m build)
elif [ -f "$MODULE/Cargo.toml" ]; then
  (cd "$MODULE" && cargo build --release)
elif [ -f "$MODULE/go.mod" ]; then
  (cd "$MODULE" && go build ./...)
else
  echo "⚠️ Unknown language, skipping."
fi
EOF
chmod +x "$OUT_DIR/monorepo/scripts/build-module.sh"

cat > "$OUT_DIR/monorepo/scripts/generate_dependency_graph.sh" << 'EOF'
#!/usr/bin/env bash
set -euo pipefail
FORMAT="${1:-svg}"
OUT_DIR="./graphs"
OUT_FILE="$OUT_DIR/dependency-graph.dot"
mkdir -p "$OUT_DIR"
npx ts-node ./monorepo-manager/src/cli.ts graph --format dot --out "$OUT_FILE"
if [ "$FORMAT" != "dot" ]; then
  dot -T"$FORMAT" "$OUT_FILE" -o "$OUT_DIR/dependency-graph.$FORMAT"
fi
EOF
chmod +x "$OUT_DIR/monorepo/scripts/generate_dependency_graph.sh"

# -------------------------------
# 2️⃣ Publishing scripts
# -------------------------------
mkdir -p "$OUT_DIR/monorepo/publishing"
for lang in java node go python rust; do
  cat > "$OUT_DIR/monorepo/publishing/publish-$lang.sh" << EOF
#!/usr/bin/env bash
set -euo pipefail
echo "📦 Publishing $lang modules..."
# Example placeholder: implement publishing logic per language
EOF
  chmod +x "$OUT_DIR/monorepo/publishing/publish-$lang.sh"
done

# -------------------------------
# 3️⃣ Change detection
# -------------------------------
mkdir -p "$OUT_DIR/monorepo/change-detection"
cat > "$OUT_DIR/monorepo/change-detection/detect-changed-modules.sh" << 'EOF'
#!/usr/bin/env bash
echo "Detecting changed modules..."
git diff --name-only HEAD~1 HEAD | grep -E 'services/|libs/' || true
EOF
chmod +x "$OUT_DIR/monorepo/change-detection/detect-changed-modules.sh"

cat > "$OUT_DIR/monorepo/change-detection/affected-tests.sh" << 'EOF'
#!/usr/bin/env bash
echo "Running tests for affected modules..."
# Example placeholder
EOF
chmod +x "$OUT_DIR/monorepo/change-detection/affected-tests.sh"

# -------------------------------
# 4️⃣ Dependency management
# -------------------------------
mkdir -p "$OUT_DIR/monorepo/dependency-management"
cat > "$OUT_DIR/monorepo/dependency-management/upgrade-deps.sh" << 'EOF'
#!/usr/bin/env bash
echo "Upgrading dependencies..."
# Placeholder logic for multi-language dep upgrade
EOF
chmod +x "$OUT_DIR/monorepo/dependency-management/upgrade-deps.sh"
touch "$OUT_DIR/monorepo/dependency-management/dependency-report.yaml"

# -------------------------------
# 5️⃣ Orchestration
# -------------------------------
mkdir -p "$OUT_DIR/monorepo/orchestration"
cat > "$OUT_DIR/monorepo/orchestration/build-order.yaml" << 'EOF'
version: 1
description: "Canonical polyglot build order"
stages:
  - name: base-languages
    modules:
      - config/languages/java/maven
      - config/languages/node/npm
      - config/languages/python/pyproject.toml
      - config/languages/rust/cargo-config.toml
      - config/languages/go/go.env
  - name: shared-libs
    modules:
      - libs/java/*
      - libs/node/*
      - libs/python/*
      - libs/rust/*
      - libs/go/*
  - name: core-services
    modules:
      - services/templates/microservice-java
      - services/templates/microservice-node
      - services/templates/microservice-go
      - services/templates/microservice-python
      - services/templates/microservice-rust
EOF

cat > "$OUT_DIR/monorepo/orchestration/release-orchestrator.sh" << 'EOF'
#!/usr/bin/env bash
set -euo pipefail
echo "Running release orchestrator based on build-order.yaml..."
EOF
chmod +x "$OUT_DIR/monorepo/orchestration/release-orchestrator.sh"
touch "$OUT_DIR/monorepo/orchestration/orchestration-docs.md"

# -------------------------------
# 6️⃣ Monorepo health check
# -------------------------------
touch "$OUT_DIR/monorepo/monorepo-health-check.md"

# -------------------------------
# 7️⃣ Polyglot microservice templates
# -------------------------------
mkdir -p "$OUT_DIR/services/templates"

# Python microservice
mkdir -p "$OUT_DIR/services/templates/microservice-python/src"
cat > "$OUT_DIR/services/templates/microservice-python/pyproject.toml" << EOF
[build-system]
requires = ["setuptools>=42", "wheel"]
build-backend = "setuptools.build_meta"
EOF
touch "$OUT_DIR/services/templates/microservice-python/src/__init__.py"

# Rust microservice
mkdir -p "$OUT_DIR/services/templates/microservice-rust/src"
cat > "$OUT_DIR/services/templates/microservice-rust/Cargo.toml" << EOF
[package]
name = "microservice-rust"
version = "0.1.0"
edition = "2021"
EOF
cat > "$OUT_DIR/services/templates/microservice-rust/src/main.rs" << EOF
fn main() {
    println!("Hello, Rust microservice!");
}
EOF

# Java microservice
mkdir -p "$OUT_DIR/services/templates/microservice-java/src/main/java"
cat > "$OUT_DIR/services/templates/microservice-java/pom.xml" << EOF
<project>
  <modelVersion>4.0.0</modelVersion>
  <groupId>com.example</groupId>
  <artifactId>microservice-java</artifactId>
  <version>0.1.0</version>
</project>
EOF
cat > "$OUT_DIR/services/templates/microservice-java/src/main/java/App.java" << EOF
public class App {
    public static void main(String[] args) {
        System.out.println("Hello, Java microservice!");
    }
}
EOF

# Go microservice
mkdir -p "$OUT_DIR/services/templates/microservice-go"
cat > "$OUT_DIR/services/templates/microservice-go/go.mod" << EOF
module microservice-go
go 1.21
EOF
cat > "$OUT_DIR/services/templates/microservice-go/main.go" << EOF
package main
import "fmt"
func main() { fmt.Println("Hello, Go microservice!") }
EOF

# Node/TS microservice
mkdir -p "$OUT_DIR/services/templates/microservice-node/src"
cat > "$OUT_DIR/services/templates/microservice-node/package.json" << EOF
{
  "name": "microservice-node",
  "version": "0.1.0",
  "main": "src/index.ts",
  "scripts": { "build": "tsc" },
  "devDependencies": { "typescript": "^5.1.0" }
}
EOF
cat > "$OUT_DIR/services/templates/microservice-node/tsconfig.json" << EOF
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "outDir": "dist",
    "rootDir": "src"
  }
}
EOF
cat > "$OUT_DIR/services/templates/microservice-node/src/index.ts" << EOF
console.log("Hello, Node/TS microservice!");
EOF

# -------------------------------
# 8️⃣ GitHub Workflows
# -------------------------------
mkdir -p "$OUT_DIR/.github/workflows"
cat > "$OUT_DIR/.github/workflows/ci.yml" << 'EOF'
name: CI
on: [push, pull_request]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - run: ./run_full_monorepo_test.sh
EOF
cat > "$OUT_DIR/.github/workflows/cd.yml" << 'EOF'
name: CD
on: workflow_dispatch
jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - run: ./run_full_monorepo_test.sh
EOF
cat > "$OUT_DIR/.github/workflows/dependency-graph.yml" << 'EOF'
name: Dependency Graph
on:
  workflow_dispatch:
jobs:
  graph:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - run: ./config/monorepo/scripts/generate_dependency_graph.sh svg
EOF

# -------------------------------
# 9️⃣ Top-level run script
# -------------------------------
cat > "$OUT_DIR/run_full_monorepo_test.sh" << 'EOF'
#!/usr/bin/env bash
set -euo pipefail
./config/monorepo/scripts/build-module.sh ./services/templates/microservice-python
./config/monorepo/scripts/build-module.sh ./services/templates/microservice-rust
./config/monorepo/scripts/build-module.sh ./services/templates/microservice-java
./config/monorepo/scripts/build-module.sh ./services/templates/microservice-go
./config/monorepo/scripts/build-module.sh ./services/templates/microservice-node
./config/monorepo/orchestration/release-orchestrator.sh
./config/monorepo/scripts/generate_dependency_graph.sh svg
EOF
chmod +x "$OUT_DIR/run_full_monorepo_test.sh"

# -------------------------------
# 10️⃣ Create tarball
# -------------------------------
TARBALL_NAME="config_with_full_monorepo_manager_complete.tar.gz"
tar -czf "$TARBALL_NAME" -C "$(dirname "$OUT_DIR")" "$(basename "$OUT_DIR")"

echo "✅ Fully populated tarball created: $TARBALL_NAME"
