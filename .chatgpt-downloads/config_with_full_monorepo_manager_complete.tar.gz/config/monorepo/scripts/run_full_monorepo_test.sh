#!/usr/bin/env bash
set -euo pipefail

CONFIG_DIR="./config"

echo "📂 Starting full monorepo test sequence in $CONFIG_DIR"

# 1️⃣ Build all Python microservices
echo "🐍 Building Python microservices..."
find $CONFIG_DIR/services/templates -name pyproject.toml | while read -r pyproj; do
    module_dir=$(dirname "$pyproj")
    echo "Building $module_dir"
    (cd "$module_dir" && python3 -m pip install --upgrade build wheel setuptools && python3 -m build)
done

# 2️⃣ Build all Rust microservices
echo "🦀 Building Rust microservices..."
find $CONFIG_DIR/services/templates -name Cargo.toml | while read -r cargo; do
    module_dir=$(dirname "$cargo")
    echo "Building $module_dir"
    (cd "$module_dir" && cargo build --release)
done

# 3️⃣ Build all Java microservices
echo "☕ Building Java microservices..."
find $CONFIG_DIR/services/templates -name pom.xml | while read -r pom; do
    module_dir=$(dirname "$pom")
    echo "Building $module_dir"
    (cd "$module_dir" && mvn clean install -B)
done

# 4️⃣ Build all Go microservices
echo "🐹 Building Go microservices..."
find $CONFIG_DIR/services/templates -name go.mod | while read -r mod; do
    module_dir=$(dirname "$mod")
    echo "Building $module_dir"
    (cd "$module_dir" && go build ./...)
done

# 5️⃣ Build all Node/TypeScript microservices
echo "🟢 Building Node/TypeScript microservices..."
find $CONFIG_DIR/services/templates -name package.json | while read -r pkg; do
    module_dir=$(dirname "$pkg")
    echo "Building $module_dir"
    (cd "$module_dir" && npm install && npm run build)
done

# 6️⃣ Run the monorepo orchestrator
echo "🚀 Running release orchestrator..."
chmod +x $CONFIG_DIR/monorepo/orchestration/release-orchestrator.sh
$CONFIG_DIR/monorepo/orchestration/release-orchestrator.sh

# 7️⃣ Optional: Publish all services (requires env vars)
echo "📦 Publishing all services..."
export NPM_REGISTRY="${NPM_REGISTRY:-}"
export PYPI_REPOSITORY="${PYPI_REPOSITORY:-}"
export MAVEN_REPO_URL="${MAVEN_REPO_URL:-}"
export CRATES_REGISTRY="${CRATES_REGISTRY:-}"
export GO_PROXY="${GO_PROXY:-}"

for lang in java node go python rust; do
    script="$CONFIG_DIR/monorepo/publishing/publish-$lang.sh"
    if [ -f "$script" ]; then
        chmod +x "$script"
        echo "Publishing $lang modules via $script"
        "$script"
    else
        echo "⚠️ Script not found for $lang: $script"
    fi
done

# 8️⃣ Generate dependency graph at the end
echo "📊 Generating dependency graph..."
GRAPH_SCRIPT="$CONFIG_DIR/monorepo/scripts/generate_dependency_graph.sh"
if [ -f "$GRAPH_SCRIPT" ]; then
    chmod +x "$GRAPH_SCRIPT"
    "$GRAPH_SCRIPT" svg
else
    echo "⚠️ Dependency graph script not found: $GRAPH_SCRIPT"
fi

echo "✅ Full monorepo build, optional publish, and graph generation complete."
