# Monorepo Health Check

Tracks the health of the monorepo.

## Metrics
- Dependency freshness (per language).
- Module build/test success rates.
- Time to release (CI/CD throughput).
- Number of changed modules per commit.
- Security scan status.

## Automation
Run:
```bash
./config/monorepo/change-detection/detect-changed-modules.sh origin/main
./config/monorepo/change-detection/affected-tests.sh origin/main
./config/monorepo/dependency-management/upgrade-deps.sh
./config/monorepo/orchestration/release-orchestrator.sh
```
