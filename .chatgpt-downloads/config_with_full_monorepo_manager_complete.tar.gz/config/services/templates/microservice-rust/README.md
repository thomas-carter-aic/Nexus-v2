# Microservice Rust Template
Sample Rust microservice template using Actix Web with Dockerfile.
