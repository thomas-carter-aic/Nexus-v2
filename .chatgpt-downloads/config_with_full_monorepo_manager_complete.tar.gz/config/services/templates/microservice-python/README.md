# Microservice Python Template
Sample Python microservice template with FastAPI and Dockerfile.
