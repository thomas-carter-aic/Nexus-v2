#!/usr/bin/env bash
set -euo pipefail
./config/monorepo/scripts/build-module.sh ./services/templates/microservice-python
./config/monorepo/scripts/build-module.sh ./services/templates/microservice-rust
./config/monorepo/scripts/build-module.sh ./services/templates/microservice-java
./config/monorepo/scripts/build-module.sh ./services/templates/microservice-go
./config/monorepo/scripts/build-module.sh ./services/templates/microservice-node
./config/monorepo/orchestration/release-orchestrator.sh
./config/monorepo/scripts/generate_dependency_graph.sh svg
