# Monorepo Manager CLI

This CLI provides full-featured monorepo operations: detect changed modules, run affected tests, generate dependency graph, publish modules and orchestrate releases.

Install:

```sh
npm install
npm run build
# or run with ts-node: npx ts-node src/cli.ts <cmd>
```

Examples:

```sh
npx ts-node src/cli.ts list
npx ts-node src/cli.ts changed
npx ts-node src/cli.ts test
npx ts-node src/cli.ts graph
npx ts-node src/cli.ts release
```
