#!/usr/bin/env node
import { Command } from 'commander';
import { listModules } from './lib/modules';
import { detectChangedModules } from './lib/changed';
import { runTests } from './lib/test';
import { dependencyGraph } from './lib/graph';
import { orchestrateRelease, publishModule } from './lib/publish';
import { runParallel } from './lib/parallel';

const program = new Command();

program.name('monorepo').description('Monorepo Manager CLI').version('0.1.0');

program
  .command('list')
  .description('List modules declared in repo-metadata/MODULES.yaml')
  .action(async () => {
    const mods = await listModules();
    console.log(mods.join('\n'));
  });

program
  .command('changed')
  .description('Detect changed modules vs a base ref (defaults to origin/main)')
  .option('-b, --base <ref>', 'Base git ref', 'origin/main')
  .action(async (opts) => {
    const changed = await detectChangedModules(opts.base);
    console.log(changed.join('\n'));
  });

program
  .command('test [modules...]')
  .description('Run tests for modules (or for detected changed modules if none provided)')
  .option('-p, --parallel <n>', 'parallelism', '4')
  .action(async (modules, opts) => {
    let mods = modules && modules.length ? modules : await detectChangedModules('origin/main');
    if (mods.length === 0) { console.log('No modules to test'); return; }
    await runTests(mods, Number(opts.parallel));
  });

program
  .command('graph')
  .description('Produce a dependency graph (heuristic) for modules')
  .action(async () => {
    const g = await dependencyGraph();
    console.log(JSON.stringify(g, null, 2));
  });

program
  .command('publish <module>')
  .description('Publish a single module using publishing scripts or native tooling')
  .action(async (module) => {
    await publishModule(module);
  });

program
  .command('release')
  .description('Orchestrate a release using repo-metadata/build-order.yaml')
  .option('-s, --skip-tests', 'skip running tests before publish')
  .action(async (opts) => {
    await orchestrateRelease({ skipTests: !!opts.skipTests });
  });

program
  .command('parallel <cmd...>')
  .description('Run arbitrary shell commands in parallel (limited concurrency)')
  .option('-c, --concurrency <n>', 'concurrency', '4')
  .action(async (cmds, opts) => {
    await runParallel(cmds, Number(opts.concurrency));
  });

program.parse(process.argv);
