import { execSync } from 'child_process';
import path from 'path';
import { readModulesMap } from './modules';

export async function detectChangedModules(baseRef = 'origin/main'): Promise<string[]> {
  const cwd = process.cwd();
  let files = '';
  try {
    files = execSync(`git diff --name-only ${baseRef}`, { encoding: 'utf8' });
  } catch (e) {
    // fallback to last commit
    files = execSync('git diff --name-only HEAD~1', { encoding: 'utf8' });
  }
  const changedFiles = files.split('\n').filter(Boolean);
  const modulesMap = await readModulesMap();
  const changed = new Set<string>();
  for (const f of changedFiles) {
    for (const [name, p] of Object.entries(modulesMap)) {
      if (f.startsWith(p + '/')) changed.add(p);
    }
  }
  return Array.from(changed);
}
