import fs from 'fs/promises';
import path from 'path';
import yaml from 'js-yaml';

export async function listModules(): Promise<string[]> {
  const p = path.resolve(process.cwd(), 'config/repo-metadata/MODULES.yaml');
  const raw = await fs.readFile(p, 'utf8');
  const doc = yaml.load(raw) as any;
  if (!Array.isArray(doc)) return [];
  return doc.map((m: any) => m.path || m.name).filter(Boolean);
}

export async function readModulesMap(): Promise<Record<string,string>> {
  const p = path.resolve(process.cwd(), 'config/repo-metadata/MODULES.yaml');
  const raw = await fs.readFile(p, 'utf8');
  const doc = yaml.load(raw) as any;
  const out: Record<string,string> = {};
  if (Array.isArray(doc)) {
    for (const m of doc) {
      if (m && m.name && m.path) out[m.name] = m.path;
    }
  }
  return out;
}
