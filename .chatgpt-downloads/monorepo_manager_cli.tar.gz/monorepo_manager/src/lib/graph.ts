import fs from 'fs/promises';
import path from 'path';
import { readModulesMap } from './modules';

// Heuristic dependency graph: scan module folders for occurrences of other module names in source files
export async function dependencyGraph(): Promise<Record<string,string[]>> {
  const modules = await readModulesMap();
  const out: Record<string,string[]> = {};
  const names = Object.keys(modules);
  for (const [name, p] of Object.entries(modules)) {
    out[name] = [];
    // scan files under p
    try {
      const files = await collectFiles(p);
      const text = files.map(f=>f.content).join('\n');
      for (const other of names) {
        if (other === name) continue;
        if (text.includes(other) || text.includes(modules[other])) out[name].push(other);
      }
    } catch (e) {
      // ignore
    }
  }
  return out;
}

async function collectFiles(root: string) {
  const res: {path:string,content:string}[] = [];
  async function walk(dir: string) {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const e of entries) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) await walk(p);
      else {
        try { const c = await fs.readFile(p, 'utf8'); res.push({path:p,content:c}); } catch {}
      }
    }
  }
  await walk(root);
  return res;
}
