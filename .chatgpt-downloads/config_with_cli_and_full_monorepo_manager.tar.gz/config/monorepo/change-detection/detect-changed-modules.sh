#!/usr/bin/env bash
# detect changed modules