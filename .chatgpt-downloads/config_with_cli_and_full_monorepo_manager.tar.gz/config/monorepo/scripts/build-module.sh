#!/usr/bin/env bash
# build module