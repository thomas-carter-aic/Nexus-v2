#!/usr/bin/env bash
# upgrade deps