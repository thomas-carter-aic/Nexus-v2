    #!/usr/bin/env sh
set -euo pipefail
NAME="$1"
PATH_TO_SERVICES="$2"

if [ -z "$NAME" ] || [ -z "$PATH_TO_SERVICES" ]; then
  echo "Usage: $0 <service-name> <path-to-services-dir>"
  exit 2
fi

mkdir -p "$PATH_TO_SERVICES/$NAME"
cat > "$PATH_TO_SERVICES/$NAME/README.md" <<'EOF'
# SERVICE: %s

This is a scaffolded microservice. Replace with your implementation.
EOF

printf "Created %s\n" "$PATH_TO_SERVICES/$NAME"
