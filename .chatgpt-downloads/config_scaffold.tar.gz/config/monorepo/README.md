    # Manual Monorepo Operations

This document explains how to operate the monorepo without a build orchestration tool.

Key scripts live in config/monorepo and are designed to be called from CI or locally.
