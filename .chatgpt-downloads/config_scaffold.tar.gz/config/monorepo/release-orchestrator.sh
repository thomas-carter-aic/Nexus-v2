    #!/usr/bin/env sh
set -euo pipefail
ROOT_DIR="$(dirname "$0")/.."
ROOT_DIR="$(cd "$ROOT_DIR" && pwd)"
BUILD_ORDER_FILE="$ROOT_DIR/repo-metadata/build-order.yaml"
MODULES_FILE="$ROOT_DIR/repo-metadata/MODULES.yaml"

command -v yq >/dev/null 2>&1 || { echo 'yq is required for release-orchestrator. Install from https://github.com/mikefarah/yq' >&2; exit 1; }

# iterate build order and publish each module if it exists
for module in $(yq e '.[]' "$BUILD_ORDER_FILE"); do
  # lookup path in MODULES.yaml
  path=$(yq e ".[] | select(.name == \"${module}\") | .path" "$MODULES_FILE")
  if [ -n "$path" ] && [ -d "$path" ]; then
    echo "Releasing ${module} at ${path}"
    case "${path}" in
      *node*|*js*|*ts*) sh "$ROOT_DIR/monorepo/publish-node.sh" "$path" ;;
      *java*|*gradle*|*mvn*) sh "$ROOT_DIR/monorepo/publish-java.sh" "$path" ;;
      *go*|*golang*) sh "$ROOT_DIR/monorepo/publish-go.sh" "$path" ;;
      *) echo "No publish rule for ${path}, please extend release-orchestrator." ;;
    esac
  else
    echo "Module ${module} not found or path missing, skipping." >&2
  fi
done
