    #!/usr/bin/env sh
set -euo pipefail
MODULE_PATH="$1"

if [ -z "${MODULE_PATH}" ] ; then
  echo "Usage: $0 <path-to-node-package>"
  exit 2
fi

echo "Publishing Node module at ${MODULE_PATH}..."
cd "${MODULE_PATH}"
if [ -f package.json ]; then
  # default: publish to npm registry configured in .npmrc or via env NPM_TOKEN
  npm --no-git-tag-version version patch
  npm publish --access public
else
  echo "No package.json found in ${MODULE_PATH}, skipping." >&2
  exit 1
fi
