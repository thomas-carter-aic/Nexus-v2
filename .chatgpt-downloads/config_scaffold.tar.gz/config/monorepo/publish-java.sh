    #!/usr/bin/env sh
set -euo pipefail

MODULE_PATH="$1"

if [ -z "${MODULE_PATH}" ] ; then
  echo "Usage: $0 <path-to-java-module>"
  exit 2
fi

echo "Publishing Java module at ${MODULE_PATH}..."
cd "${MODULE_PATH}"
# sensible default: use mvn or gradle if present
if [ -f pom.xml ]; then
  mvn -B -DskipTests deploy
elif [ -f build.gradle ] || [ -f build.gradle.kts ]; then
  ./gradlew publish
else
  echo "No maven/gradle build found in ${MODULE_PATH}, skipping." >&2
  exit 1
fi
