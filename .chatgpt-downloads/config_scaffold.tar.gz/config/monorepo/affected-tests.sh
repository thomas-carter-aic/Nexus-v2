    #!/usr/bin/env sh
set -euo pipefail
MODULE_PATHS="$@"

# Example: run tests for each module passed in
for m in $MODULE_PATHS; do
  echo "Running tests for: $m"
  if [ -f "$m/package.json" ]; then
    (cd "$m" && npm test)
  elif [ -f "$m/pom.xml" ]; then
    (cd "$m" && mvn -B -DskipTests=false test)
  elif [ -f "$m/go.mod" ]; then
    (cd "$m" && go test ./...)
  else
    echo "No test command known for $m, skipping." >&2
  fi
done
