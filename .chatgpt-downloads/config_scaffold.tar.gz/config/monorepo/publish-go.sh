    #!/usr/bin/env sh
set -euo pipefail
MODULE_PATH="$1"

if [ -z "${MODULE_PATH}" ] ; then
  echo "Usage: $0 <path-to-go-module>"
  exit 2
fi

echo "Publishing Go module at ${MODULE_PATH}..."
cd "${MODULE_PATH}"
# Go modules are published by tagging a VCS tag; this script prints instructions
echo "To publish a new version of this Go module, create a git tag of the form vX.Y.Z and push it."
