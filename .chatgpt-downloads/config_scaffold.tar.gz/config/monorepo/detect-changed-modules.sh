    #!/usr/bin/env sh
set -euo pipefail

# Detect changed top-level modules using git. Relies on repo-metadata/MODULES.yaml.
ROOT_DIR="$(dirname "$0")/.."
ROOT_DIR="$(cd "$ROOT_DIR" && pwd)"
MODULES_FILE="$ROOT_DIR/repo-metadata/MODULES.yaml"

if [ ! -f "$MODULES_FILE" ]; then
  echo "Missing $MODULES_FILE" >&2
  exit 1
fi

# get changed files vs main (or origin/main)
BASE_REF="${BASE_REF:-origin/main}"
CHANGED_FILES=$(git diff --name-only "$BASE_REF" --)

# simple parser: match 'path:' entries from MODULES.yaml
awk '/path:/ {print $2}' "$MODULES_FILE" | while read -r module_path; do
  if echo "$CHANGED_FILES" | grep -q "^${module_path}/"; then
    echo "$module_path"
  fi
done
