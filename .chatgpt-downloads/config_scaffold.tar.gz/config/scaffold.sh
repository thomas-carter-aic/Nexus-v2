    #!/usr/bin/env sh
set -euo pipefail

# This script will create a minimal config/ layout and populate it with the primary scripts
# Intended to be run from your repo root and will create ./config if missing.
TARGET_DIR="${1:-config}"
mkdir -p "$TARGET_DIR"

# Copy this file tree into the target. If this script is packaged with the files, implement copy logic.
# For now this is a convenience wrapper that explains next steps.
cat > "$TARGET_DIR/README_AUTOGEN.md" <<'EOF'
This file indicates you ran the scaffold helper.
Please copy files from config_scaffold/ into this directory, or run the generator that shipped with the distribution.
EOF

echo "Scaffold placeholder created at $TARGET_DIR."
