    # Monorepo layout

Top-level layout conventions used by repository scripts:

- services/: runtime services (each folder is one deployable service)
- libs/: shared libraries grouped by language
- tools/: dev tooling scripts
- config/: repository-wide configuration (this directory)

Naming and ownership:
- Each module should have an OWNERS file in its root listing approvers and codeowners.
